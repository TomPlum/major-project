package robocode;

/*
public class TestRunner {
    public static void main(String[] args) {
        Result res = JUnitCore.runClasses(RobotControllerTest.class);
    }
}
*/