package controller;

public class StartRobocode {
    public static void main(String[] args) {
        //for (int i = 0; i < 3; i++) {
            GameConfigurer.startBattle();
        //}
    }
}
